/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils3.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkamanur <gkamanur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/27 12:06:18 by gkamanur          #+#    #+#             */
/*   Updated: 2025/08/28 16:41:47 by gkamanur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/minishell.h"

int	check_unclosed_quotes(const char *line)
{
	int		i;
	char	quote;

	i = 0;
	quote = 0;
	while (line[i])
	{
		if (!quote && (line[i] == '\'' || line[i] == '"'))
			quote = line[i];
		else if (quote && line[i] == quote)
			quote = 0;
		i++;
	}
	return (quote != 0);
}

int	check_incomplete_syntax(const char *line)
{
	int		i;
	char	quote;

	i = 0;
	quote = 0;
	while (line[i])
	{
		if (!quote && (line[i] == '\'' || line[i] == '"'))
			quote = line[i];
		else if (quote && line[i] == quote)
			quote = 0;
		i++;
	}
	if (quote)
		return (1);
	while (i > 0 && (line[i - 1] == ' ' || line[i - 1] == '\t'))
		i--;
	if (i > 0 && (line[i - 1] == '\\'
			|| line[i - 1] == '&'))
		return (1);
	return (0);
}

char	*read_input_with_quotes(const char *prompt,
		const char *secondary_prompt)
{
	char	*line;
	char	*next;
	char	*tmp;
	char	*joined;

	line = readline(prompt);
	if (!line)
		return (NULL);
	while (check_incomplete_syntax(line))
	{
		next = readline(secondary_prompt);
		if (!next)
			break ;
		tmp = ft_strjoin(line, "\n");
		joined = ft_strjoin(tmp, next);
		free(line);
		free(tmp);
		free(next);
		line = joined;
	}
	return (line);
}
