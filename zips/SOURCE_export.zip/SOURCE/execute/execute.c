/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   execute.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkamanur <gkamanur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/20 10:59:45 by gkamanur          #+#    #+#             */
/*   Updated: 2025/08/25 16:46:17 by gkamanur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/minishell.h"

int	count_cmds(t_comnd *cmd)
{
	int	count;

	count = 0;
	while (cmd)
	{
		count++;
		cmd = cmd->next;
	}
	return (count);
}

int	is_parent_builtin(t_comnd *cmd)
{
	if (!cmd->next && is_builtin_argv(cmd->av_cmd))
		if (!ft_strcmp(cmd->av_cmd[0], "cd") || !ft_strcmp(cmd->av_cmd[0],
				"export") || !ft_strcmp(cmd->av_cmd[0], "unset")
			|| !ft_strcmp(cmd->av_cmd[0], "exit"))
			return (1);
	return (0);
}

void	run_child(t_pipe *ctx)
{
	redirect_input(ctx->cmd, ctx->prev);
	redirect_output(ctx->cmd, ctx->pfd);
	if (ctx->pfd[0] >= 0)
		close(ctx->pfd[0]);
	if (ctx->pfd[1] >= 0)
		close(ctx->pfd[1]);
	if (ctx->prev >= 0)
		close(ctx->prev);
	if (is_builtin_argv(ctx->cmd->av_cmd))
	{
		exit(ft_dispatch_builtin(ctx->cmd->av_cmd, &ctx->shell->env_list,
				ctx->shell));
	}
	exec_command(ctx->cmd, ctx->envp);
	exit(1);
}

void	ft_wait_all(pid_t *pids, int count, t_shell *shell)
{
	int	i;
	int	status;

	i = 0;
	while (i < count)
	{
		waitpid(pids[i], &status, 0);
		if (i == count - 1)
		{
			if (WIFEXITED(status))
				shell->last_status = WEXITSTATUS(status);
			else if (WIFSIGNALED(status))
				shell->last_status = 128 + WTERMSIG(status);
		}
		i++;
	}
}
