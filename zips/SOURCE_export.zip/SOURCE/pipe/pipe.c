/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipe.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkamanur <gkamanur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/07 11:53:50 by robello           #+#    #+#             */
/*   Updated: 2025/08/22 13:53:35 by gkamanur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/minishell.h"

static void	execute_pipeline_loop(t_comnd *cmds, t_shell *shell, pid_t *pids,
		char **envp)
{
	t_pipe	ctx;

	ctx.cmd = cmds;
	ctx.shell = shell;
	ctx.pids = pids;
	ctx.prev = -1;
	ctx.i = 0;
	ctx.envp = envp;
	while (ctx.cmd)
	{
		ft_open_main(ctx.cmd, 0);
		setup_pipe(ctx.pfd, ctx.cmd);
		launch_child(&ctx);
		close_parent_fds(&ctx.prev, ctx.pfd);
		ctx.cmd = ctx.cmd->next;
		ctx.i++;
	}
}

void	ft_pipe_up_bonus(t_comnd *cmds, t_shell *shell)
{
	pid_t	*pids;
	char	**envp;
	int		count;

	count = setup_allocations(cmds, shell, &pids, &envp);
	if (handle_parent_builtin(cmds, shell, envp, pids))
		return ;
	execute_pipeline_loop(cmds, shell, pids, envp);
	ft_wait_all(pids, count, shell);
	cleanup_all_fds(cmds);
	free_env_array(envp);
	free(pids);
}
